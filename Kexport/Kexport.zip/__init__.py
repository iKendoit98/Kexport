
bl_info = {
    "name" : "Kexporter",
    "author" : "iKendoit",
    "description" : "Batch Exporter focused on game exports",
    "blender" : (2, 80, 2),
    "version" : (0, 0, 1),
    "location" : "Kexport panel",
    "category" : "Import-Export"
}
     



import bpy

from bpy.types import Panel

from . Kexport_op import *
from . kex_export import *
from . kex_panel import *





# classes = (Kex_Export, Kexport_OT_Operator, Kexport_Panel)
# register, unregister = bpy.utils.register_classes_factory(classes)

def register():
    bpy.utils.register_class(Kexport_OT_Operator)
    bpy.utils.register_class(Kexport_Panel)

def unregister():
    bpy.utils.unregister_class(Kexport_OT_Operator)
    bpy.utils.unregister_class(Kexport_Panel)


if __name__ == "__main__":
    register()