import bpy
from bpy.types import Panel


class Kexport_Panel(bpy.types.Panel):
    bl_label = "FBX Export"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Kexport"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row()
        row.label(text="Export folder:")
        